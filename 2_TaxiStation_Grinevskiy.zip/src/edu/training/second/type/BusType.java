package edu.training.second.type;

/**
 * Created by Roman on 27.09.2016.
 */
public enum BusType {
        TOURISM, TRAFFIC, VIP
}
