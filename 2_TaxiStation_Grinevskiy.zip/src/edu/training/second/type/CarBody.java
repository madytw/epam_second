package edu.training.second.type;

/**
 * Created by Roman on 26.09.2016.
 */
public enum CarBody {
        SEDAN, MINIVAN, MINIBUS, UNIVERSAL, WAGON
}
