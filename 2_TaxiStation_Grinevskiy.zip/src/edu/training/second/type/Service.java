package edu.training.second.type;

/**
 * Created by Roman on 27.09.2016.
 */
public enum Service {
        WIFI, AIR_CONDITIONER, PHONE_CHARGER
}
