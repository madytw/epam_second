package test.edu.training.second;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 * Created by Roman on 09.10.2016.
 */

@Suite.SuiteClasses({CarCreationTest.class, TaxiStationExceptionTest.class})
@RunWith(Suite.class)
public class TaxiStationTestSuite {
}



